# 良禽品牌体 安装说明

- 当前发行包：`liangqin-brand-body`
- 对外唯一入口词：`良禽品牌体`
- 当前版本：`2.0.0`
- 旧名 `liangqin-brand-openclaw` 仅作迁移兼容说明，不再作为推荐入口。

## 安装方式

1. 将整个 `liangqin-brand-body/` 目录复制到目标 OpenClaw skills 目录；或直接运行：
```bash
python3 scripts/install_into_openclaw.py
```
2. 确保保留 `DESIGN.md`、`DESIGN-GOVERNANCE.md`、`foundation-dna/design-dna.zh-CN.json`、`design-packs/`、`SKILL.md`、`protocols/`、`recipes/`、`examples/`、`evaluation/` 与 `skill-release.json`。
3. 默认先读取 `DESIGN.md`，再读取 `protocols/brand-boundaries.zh-CN.json` 与 `recipes/module-recipes.zh-CN.json`。
4. 如果用户明确说“良禽佳木apple风”，再补读 `design-packs/liangqin-apple.json`。
5. 优先按 `SKILL.md` 中的输入合同喂入品牌 brief、产品资料和参考页面。
