# 良禽品牌体 安装说明

- 当前发行包：`liangqin-brand-body`
- 对外推荐触发词：`良禽品牌体`
- 对外兼容触发词：`良禽佳木品牌体`
- 对内稳定 slug：`liangqin-brand-openclaw`
- 当前版本：`2.2.0`
- 旧名 `liangqin-brand-openclaw` 仅作迁移兼容说明，不再作为推荐入口。
- 旧的公关稿、品牌通稿、`/小强体`、`/厂长模式`、`/硬核木匠` 仅保留为次级写作能力，不再作为顶层品牌入口。

## 入口路由

默认优先使用 `良禽品牌体 / 良禽佳木品牌体` 作为顶层品牌入口。

以下请求应直接交给 `良禽品牌体 / 良禽佳木品牌体`：

- 首页
- 产品详情
- 品牌页
- `DESIGN.md` / 设计系统
- 页面蓝图、模块编排、品牌视觉约束
- 图片、长图、海报、视觉稿、报价卡图、图标方案
- 风格切换，例如：`良禽佳木apple风`

只有当用户明确要求写公关稿、品牌通稿或文章时，才应转交给次级写作能力。

所有良禽视觉类请求都建议先进入 `良禽品牌体 / 良禽佳木品牌体`，先产出结构化 spec，再按渠道适配到图片、页面、长图、卡片或动效。

## 安装方式

1. 将整个 `liangqin-brand-body/` 目录复制到目标 OpenClaw skills 目录；或直接运行：
```bash
python3 scripts/install_into_openclaw.py
```
2. 确保保留 `DESIGN.md`、`CONSUMER-GUIDE.zh-CN.md`、`DESIGN-GOVERNANCE.md`、`design-standard-package.json`、`foundation-dna/design-dna.zh-CN.json`、`foundation-dna/tokens.semantic.json`、`artifact-surfaces/`、`design-packs/`、`assets/brand/asset-manifest.zh-CN.json`、`SKILL.md`、`protocols/`、`recipes/`、`examples/`、`evaluation/` 与 `skill-release.json`。
3. 安装后请保留 `EXECUTION-CHECKLIST.md`、`protocols/brand-assets.zh-CN.json`、`assets/brand/asset-manifest.zh-CN.json` 与 `assets/brand/`，这是最终视觉成品的 logo 运行时依赖。
4. 默认先读取 `DESIGN.md` 与 `CONSUMER-GUIDE.zh-CN.md`，再读取 `protocols/brand-boundaries.zh-CN.json`、`protocols/brand-assets.zh-CN.json` 与 `recipes/module-recipes.zh-CN.json`。
5. 如果工具只支持 Tier 1，至少保住 `DESIGN.md`；如果支持 Tier 2，请同时读取 `artifact-surfaces/` 与 `assets/brand/`。
6. 如果用户明确说“良禽佳木apple风”，再补读 `design-packs/liangqin-apple.json`。
7. 优先按 `SKILL.md` 中的输入合同喂入品牌 brief、产品资料和参考页面；若真实 logo 资产不可读，只允许输出结构化 spec。
